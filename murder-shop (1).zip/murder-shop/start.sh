#!/bin/sh
cd "$(dirname "$0")"
python3 server.py 8000 2>/dev/null || python server.py 8000
