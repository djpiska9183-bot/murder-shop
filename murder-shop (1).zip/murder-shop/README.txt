MURDER SHOP

Структура:
  murder-shop/
    index.html   - весь сайт (магазин + админка)
    server.py    - локальный сервер (Python)
    start.bat    - запуск на Windows (двойной клик)
    start.sh     - запуск на Mac/Linux/Termux
    README.txt   - эта инструкция

ЗАПУСК
Windows: двойной клик по start.bat, откроется http://localhost:8000
Mac/Linux: sh start.sh
Termux (Android):
  pkg install python
  termux-setup-storage
  cd ~/storage/downloads/murder-shop
  python server.py
  затем открыть в Chrome: http://localhost:8000
Без Python: можно открыть index.html прямо в Chrome (Открыть в -> Chrome).

АДМИНКА
Войти через кнопку "Войти", почта и пароль админа, затем кнопка "Админка".
Данные (товары, фото, заказы, аккаунты) хранятся в браузере.
